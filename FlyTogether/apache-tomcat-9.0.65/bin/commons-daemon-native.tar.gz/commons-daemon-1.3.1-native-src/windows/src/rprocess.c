/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "apxwin.h"
#include "private.h"
#include <tlhelp32.h>

#define CHILD_RUNNING               0x0001
#define CHILD_INITIALIZED           0x0002
#define CHILD_MAINTREAD_FINISHED    0x0004
#define PROC_INITIALIZED            0x0008
#define CHILD_TERMINATE_CODE        19640323 /* Could be any value like my birthday ;-)*/

DYNLOAD_TYPE_DECLARE(CreateRemoteThread,
                     __stdcall, HANDLE)(HANDLE, LPSECURITY_ATTRIBUTES,
                                        DWORD, LPTHREAD_START_ROUTINE,
                                        LPVOID, DWORD, LPDWORD);

DYNLOAD_TYPE_DECLARE(ExitProcess, __stdcall, void)(UINT);

#define CHECK_IF_ACTIVE(proc) \
    APXMACRO_BEGIN                                                      \
        DWORD __st;                                                     \
        if (!GetExitCodeProcess((proc)->stProcInfo.hProcess, &__st) ||  \
                                (__st != STILL_ACTIVE))                 \
            goto cleanup;                                               \
    APXMACRO_END

#define SAVE_STD_HANDLES(p) \
    APXMACRO_BEGIN                                                      \
    if ((p)->bSaveHandles) {                                            \
    (p)->hParentStdSave[0] = GetStdHandle(STD_INPUT_HANDLE);            \
    (p)->hParentStdSave[1] = GetStdHandle(STD_OUTPUT_HANDLE);           \
    (p)->hParentStdSave[2] = GetStdHandle(STD_ERROR_HANDLE);            \
    } APXMACRO_END

#define RESTORE_STD_HANDLES(p) \
    APXMACRO_BEGIN                                                      \
    if ((p)->bSaveHandles) {                                            \
    SetStdHandle(STD_INPUT_HANDLE,  (p)->hParentStdSave[0]);            \
    SetStdHandle(STD_OUTPUT_HANDLE, (p)->hParentStdSave[1]);            \
    SetStdHandle(STD_ERROR_HANDLE,  (p)->hParentStdSave[2]);            \
    } APXMACRO_END

#define REDIRECT_STD_HANDLES(p) \
    APXMACRO_BEGIN                                                      \
    if ((p)->bSaveHandles) {                                            \
    SetStdHandle(STD_INPUT_HANDLE,  (p)->hChildStdInp);                 \
    SetStdHandle(STD_OUTPUT_HANDLE, (p)->hChildStdOut);                 \
    SetStdHandle(STD_ERROR_HANDLE,  (p)->hChildStdErr);                 \
    } APXMACRO_END

typedef struct APXPROCESS {
    DWORD                   dwChildStatus;
    DWORD                   dwOptions;
    PROCESS_INFORMATION     stProcInfo;
    /* Size of chars for ANSI/Unicode programs */
    DWORD                   chSize;
    /* application working path */
    LPWSTR                  szWorkingPath;
    /* executable name */
    LPWSTR                  szApplicationExec;
    /* command line (first arg is program name for argv[0]) */
    LPWSTR                  szCommandLine;
    LPWSTR                  lpEnvironment;
    /* set of child inherited pipes */
    HANDLE                  hChildStdInp;
    HANDLE                  hChildStdOut;
    HANDLE                  hChildStdErr;
    /* parent ends of child pipes */
    HANDLE                  hChildInpWr;
    HANDLE                  hChildOutRd;
    HANDLE                  hChildErrRd;
    /* Saved console pipes */
    HANDLE                  hParentStdSave[3];
    HANDLE                  hWorkerThreads[3];
    HANDLE                  hUserToken;
    HANDLE                  hCurrentProcess;
    BOOL                    bSaveHandles;
    /** callback function */
    LPAPXFNCALLBACK         fnUserCallback;
    LPSECURITY_ATTRIBUTES   lpSA;
    LPVOID                  lpSD;
    BYTE                    bSD[SECURITY_DESCRIPTOR_MIN_LENGTH];
    BYTE                    bSA[sizeof(SECURITY_ATTRIBUTES)];

} APXPROCESS, *LPAPXPROCESS;

/** Process worker thread
 * Monitors the process thread
 */
static DWORD WINAPI __apxProcWorkerThread(LPVOID lpParameter)
{
    APXHANDLE hProcess = (APXHANDLE)lpParameter;
    LPAPXPROCESS lpProc;
    DWORD dwExitCode = 0;

    lpProc = APXHANDLE_DATA(hProcess);
    /* Wait util a process has finished its initialization.
     */
    WaitForInputIdle(lpProc->stProcInfo.hProcess, INFINITE);
    lpProc->dwChildStatus |= CHILD_INITIALIZED;
    /* Wait until the child process exits */
    if (WaitForSingleObject(lpProc->stProcInfo.hProcess,
                            INFINITE) == WAIT_OBJECT_0) {
        lpProc->dwChildStatus |= CHILD_MAINTREAD_FINISHED;

        /* store worker's exit code as VM exit code for later use */
        GetExitCodeProcess(lpProc->stProcInfo.hProcess, &dwExitCode);
        apxLogWrite(APXLOG_MARK_DEBUG "Apache Commons Daemon Child process exit code %d", dwExitCode);
        apxSetVmExitCode(dwExitCode);
    }
    ExitThread(0);
    return 0;
}

static DWORD WINAPI __apxProcStdoutThread(LPVOID lpParameter)
{
    APXHANDLE hProcess = (APXHANDLE)lpParameter;
    LPAPXPROCESS lpProc;
    APXCALLHOOK *lpCall;
    INT ch;
    DWORD dwReaded;
    lpProc = APXHANDLE_DATA(hProcess);
    while (lpProc->dwChildStatus & CHILD_RUNNING) {
        ch = 0;
        if (!ReadFile(lpProc->hChildOutRd, &ch, lpProc->chSize,
                      &dwReaded, NULL) || !dwReaded) {

            break;
        }
        if (lpProc->fnUserCallback)
            (*lpProc->fnUserCallback)(hProcess, WM_CHAR, (WPARAM)ch, (LPARAM)0);
        TAILQ_FOREACH(lpCall, &hProcess->lCallbacks, queue) {
            (*lpCall->fnCallback)(hProcess, WM_CHAR, (WPARAM)ch, (LPARAM)0);
        }
        dwReaded = 0;
        SwitchToThread();
    }
    ExitThread(0);
    return 0;
}

static DWORD WINAPI __apxProcStderrThread(LPVOID lpParameter)
{
    APXHANDLE hProcess = (APXHANDLE)lpParameter;
    LPAPXPROCESS lpProc;
    APXCALLHOOK *lpCall;
    INT ch;
    DWORD dwReaded;
    lpProc = APXHANDLE_DATA(hProcess);
    while (lpProc->dwChildStatus & CHILD_RUNNING) {
        if (!ReadFile(lpProc->hChildErrRd, &ch, lpProc->chSize,
                      &dwReaded, NULL) || !dwReaded) {

            break;
        }
        if (lpProc->fnUserCallback)
            (*lpProc->fnUserCallback)(hProcess, WM_CHAR, (WPARAM)ch, (LPARAM)1);
        TAILQ_FOREACH(lpCall, &hProcess->lCallbacks, queue) {
            (*lpCall->fnCallback)(hProcess, WM_CHAR, (WPARAM)ch, (LPARAM)1);
        }

        dwReaded = 0;
        SwitchToThread();
    }

    ExitThread(0);
    return 0;
}

static DWORD __apxProcessPutc(LPAPXPROCESS lpProc, INT ch, DWORD dwSize)
{
    if (lpProc->dwChildStatus & CHILD_RUNNING) {
        DWORD wr = 0;
        if (WriteFile(lpProc->hChildInpWr, &ch, dwSize, &wr, NULL) &&
                      wr == dwSize) {
            return 1;
        }
    }

    return 0;
}

static DWORD __apxProcessPuts(LPAPXPROCESS lpProc, LPCTSTR szString)
{
    DWORD l, n = 0;
    l = lstrlen(szString) * lpProc->chSize;
    if (lpProc->dwChildStatus & CHILD_RUNNING && l) {
        DWORD wr = 0;
        while (TRUE) {
            if (WriteFile(lpProc->hChildInpWr, szString, l,
                          &wr, NULL)) {
                n += wr;
                if (wr < l) {
                    l -= wr;
                    szString += wr;
                }
                else {
                    /* Flush the buffer */
                    FlushFileBuffers(lpProc->hChildInpWr);
                    break;
                }
            }
            else
                break;
        }
    }

    return n;
}

static DWORD __apxProcessWrite(LPAPXPROCESS lpProc, LPCVOID lpData, DWORD dwLen)
{
    LPBYTE buf = (LPBYTE)lpData;
    DWORD  n = 0;
    if (!lpData || !dwLen)
        return 0;

    if (lpProc->dwChildStatus & CHILD_RUNNING) {
        DWORD wr = 0;
        while (lpProc->dwChildStatus & CHILD_RUNNING) {
            if (WriteFile(lpProc->hChildInpWr, buf, dwLen,
                          &wr, NULL)) {
                n += wr;
                if (wr < dwLen) {
                    dwLen -= wr;
                    buf += wr;
                }
                else
                    break;
            }
            else
                break;
        }
    }

    return n;
}

/** Helper functions */
static BOOL __apxProcCreateChildPipes(LPAPXPROCESS lpProc)
{
    BOOL   rv = FALSE;

    apxLogWrite(APXLOG_MARK_DEBUG "Apache Commons Daemon procrun __apxProcCreateChildPipes()");

    if (!CreatePipe(&(lpProc->hChildStdInp),
                    &(lpProc->hChildInpWr),
                    lpProc->lpSA, 0)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        goto cleanup;
    }
    if (!SetHandleInformation(lpProc->hChildInpWr,
                              HANDLE_FLAG_INHERIT, 0)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        goto cleanup;
    }

    if (!CreatePipe(&(lpProc->hChildOutRd),
                    &(lpProc->hChildStdOut),
                    lpProc->lpSA, 0)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        goto cleanup;
    }

    if (!SetHandleInformation(lpProc->hChildOutRd,
                              HANDLE_FLAG_INHERIT, 0)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        goto cleanup;
    }

    if (!CreatePipe(&(lpProc->hChildErrRd),
                    &(lpProc->hChildStdErr),
                    lpProc->lpSA, 0)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        goto cleanup;
    }

    if (!SetHandleInformation(lpProc->hChildErrRd,
                              HANDLE_FLAG_INHERIT, 0)) {
        apxLogWrite(APXLOG_MARK_SYSERR);
        goto cleanup;
    }
    rv = TRUE;
cleanup:

    return rv;
}
/* Terminate child processes if any
 * dwProcessId : the parent process
 * dryrun : Don't kill, just list process in debug output file.
 */
static BOOL __apxProcessTerminateChild(DWORD dwProcessId, BOOL dryrun)
{
    HANDLE hProcessSnap;
    PROCESSENTRY32 pe32;

    apxLogWrite(APXLOG_MARK_DEBUG "TerminateChild 0x%08X (%d)", dwProcessId, dwProcessId );
    // Take a snapshot of all processes in the system.
    hProcessSnap = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
    if(hProcessSnap == INVALID_HANDLE_VALUE) {
        apxLogWrite(APXLOG_MARK_DEBUG "CreateToolhelp32Snapshot (of processes) failed");
        return(FALSE);
    }

    // Set the size of the structure before using it.
    pe32.dwSize = sizeof(PROCESSENTRY32);

    // Retrieve information about the first process,
    // and return if unsuccessful
    if( !Process32First(hProcessSnap, &pe32 )) {
        apxLogWrite(APXLOG_MARK_DEBUG "Process32First failed");
        CloseHandle(hProcessSnap);          // clean the snapshot object
        return(FALSE);
    }

    // Now walk the snapshot of processes, and
    // display information about each process in turn
    do {
        if (pe32.th32ParentProcessID == dwProcessId) {
            apxLogWrite(APXLOG_MARK_DEBUG "PROCESS NAME:  %S", pe32.szExeFile);

            apxLogWrite(APXLOG_MARK_DEBUG "Process ID        = 0x%08X", pe32.th32ProcessID);
            apxLogWrite(APXLOG_MARK_DEBUG "Thread count      = %d",   pe32.cntThreads);
            apxLogWrite(APXLOG_MARK_DEBUG "Parent process ID = 0x%08X", pe32.th32ParentProcessID);
            apxLogWrite(APXLOG_MARK_DEBUG "Priority base     = %d", pe32.pcPriClassBase);
            if (!dryrun) {
                HANDLE hProcess;
                hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID);
                if(hProcess != NULL) {
                   TerminateProcess(hProcess, CHILD_TERMINATE_CODE);
                   apxLogWrite(APXLOG_MARK_DEBUG "Process ID: 0x%08X (%d) Terminated!", pe32.th32ProcessID, pe32.th32ProcessID);
                   CloseHandle(hProcess);
                } else {
                   apxLogWrite(APXLOG_MARK_DEBUG "Process ID: 0x%08X (%d) Termination failed!", pe32.th32ProcessID, pe32.th32ProcessID);
                }
            }
       }

    } while(Process32Next(hProcessSnap, &pe32));
  
    CloseHandle(hProcessSnap);
    return(TRUE);
}

/* Close the process.
 * Create the remote thread and call the ExitProcess
 * Terminate the process, if all of the above fails.
 */
static BOOL __apxProcessClose(APXHANDLE hProcess)
{
    LPAPXPROCESS lpProc;
    DYNLOAD_FPTR_DECLARE(CreateRemoteThread);
    DYNLOAD_FPTR_DECLARE(ExitProcess);

    UINT    uExitCode = CHILD_TERMINATE_CODE; /* Could be any value like my birthday ;-)*/
    HANDLE  hDup, hRemote;

    lpProc = APXHANDLE_DATA(hProcess);
    CHECK_IF_ACTIVE(lpProc);

    /* dry run to get debug information */
    __apxProcessTerminateChild(lpProc->stProcInfo.dwProcessId, TRUE);
    /* Try to close the child's stdin first */
    SAFE_CLOSE_HANDLE(lpProc->hChildInpWr);
    /* Wait 1 sec for child process to
     * recognize that the stdin has been closed.
     */
    if (WaitForSingleObject(lpProc->stProcInfo.hProcess, 1000) == WAIT_OBJECT_0) {
        apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessClose Gone(input)");
        goto cleanup;
    }

    CHECK_IF_ACTIVE(lpProc);

    /* Try to create the remote thread in the child address space */
    DYNLOAD_FPTR_ADDRESS(CreateRemoteThread, KERNEL32);
    if (DuplicateHandle(lpProc->hCurrentProcess,
                        lpProc->stProcInfo.hProcess,
                        lpProc->hCurrentProcess,
                        &hDup,
                        PROCESS_ALL_ACCESS,
                        FALSE, 0)) {
        DYNLOAD_FPTR_ADDRESS(ExitProcess, KERNEL32);
        /* Now call the ExitProcess from inside the client
         * This will safely unload all the dll's.
         */
        hRemote = DYNLOAD_CALL(CreateRemoteThread)(hDup,
                                NULL, 0,
                                (LPTHREAD_START_ROUTINE)DYNLOAD_FPTR(ExitProcess),
                                (PVOID)&uExitCode, 0, NULL);
        if (!IS_INVALID_HANDLE(hRemote)) {
            if (WaitForSingleObject(lpProc->stProcInfo.hProcess,
                    2000) == WAIT_OBJECT_0) {
                DWORD status;
                if (!GetExitCodeProcess(lpProc->stProcInfo.hProcess, &status) ||
                                (status != STILL_ACTIVE)) {
                     apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessClose Gone(thread exit)");
                     /* We are here when the service starts something like wildfly via standalone.sh and wildfly doesn't terminate cleanly, 
                      * dry run is FALSE: we kill all the process of the process tree
                      */
                     __apxProcessTerminateChild(lpProc->stProcInfo.dwProcessId, FALSE);
                }


            }
            else {
		apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessClose thread exit failed, terminate!");
                TerminateProcess(lpProc->stProcInfo.hProcess, CHILD_TERMINATE_CODE);
                // __apxProcessTerminateChild ?
            }
            CloseHandle(hRemote);
        } else {
            apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessClose thread exit not usuable...");
	}
        CloseHandle(hDup);
        apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessClose Done?");
        goto cleanup;
    }

    apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessClose terminate!");
    TerminateProcess(lpProc->stProcInfo.hProcess, CHILD_TERMINATE_CODE);
    // __apxProcessTerminateChild ?

cleanup:
     /* Close the process handle */
    SAFE_CLOSE_HANDLE(lpProc->stProcInfo.hProcess);
    lpProc->dwChildStatus &= ~CHILD_RUNNING;
    return TRUE;
}

static BOOL __apxProcessCallback(APXHANDLE hObject, UINT uMsg,
                                 WPARAM wParam, LPARAM lParam)
{
    LPAPXPROCESS lpProc;

    lpProc = APXHANDLE_DATA(hObject);
    /* Call the user supplied callback first */
    if (lpProc->fnUserCallback)
        (*lpProc->fnUserCallback)(hObject, uMsg, wParam, lParam);
    switch (uMsg) {
        case WM_CLOSE:
        	/* Avoid processing the WM_CLOSE message multiple times */
        	if (lpProc->stProcInfo.hProcess == NULL) break;
            if (lpProc->dwChildStatus & CHILD_RUNNING) {
                apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessCallback: CHILD_RUNNING");
                __apxProcessClose(hObject);
                /* Wait for all worker threads to exit */
                WaitForMultipleObjects(3, lpProc->hWorkerThreads, TRUE, INFINITE);
                apxLogWrite(APXLOG_MARK_DEBUG "__apxProcessCallback: CHILD_RUNNING DONE!");
            }
            SAFE_CLOSE_HANDLE(lpProc->stProcInfo.hProcess);

            /* Close parent side of the pipes */
            SAFE_CLOSE_HANDLE(lpProc->hChildInpWr);
            SAFE_CLOSE_HANDLE(lpProc->hChildOutRd);
            SAFE_CLOSE_HANDLE(lpProc->hChildErrRd);

            SAFE_CLOSE_HANDLE(lpProc->hWorkerThreads[0]);
            SAFE_CLOSE_HANDLE(lpProc->hWorkerThreads[1]);
            SAFE_CLOSE_HANDLE(lpProc->hWorkerThreads[2]);
            SAFE_CLOSE_HANDLE(lpProc->hUserToken);
            apxFree(lpProc->szApplicationExec);
            apxFree(lpProc->szCommandLine);
            apxFree(lpProc->szWorkingPath);
            RESTORE_STD_HANDLES(lpProc);
            SAFE_CLOSE_HANDLE(lpProc->hCurrentProcess);
            if (lpProc->lpEnvironment)
                FreeEnvironmentStringsW(lpProc->lpEnvironment);

        case WM_QUIT:
            /* The process has finished
             * This is a WorkerThread message
             */
            lpProc->dwChildStatus &= ~CHILD_RUNNING;
        break;
        case WM_CHAR:
            __apxProcessPutc(lpProc, (INT)lParam, lpProc->chSize);
        break;
        case WM_SETTEXT:
            if (wParam)
                __apxProcessWrite(lpProc, (LPCVOID)lParam, (DWORD)wParam);
            else
                __apxProcessPuts(lpProc, (LPCTSTR)lParam);
        break;
        default:
        break;
    }

    return TRUE;
}

APXHANDLE
apxCreateProcessW(APXHANDLE hPool, DWORD dwOptions,
                  LPAPXFNCALLBACK fnCallback,
                  LPCWSTR szUsername, LPCWSTR szPassword,
                  BOOL bLogonAsService)
{
    APXHANDLE hProcess;
    LPAPXPROCESS lpProc;
    HANDLE hUserToken = NULL;
    if (szUsername) {
        HANDLE hUser;
        if (!LogonUserW(szUsername,
                        NULL,
                        szPassword,
                        bLogonAsService ? LOGON32_LOGON_SERVICE : LOGON32_LOGON_NETWORK,
                        LOGON32_PROVIDER_DEFAULT,
                        &hUser)) {
            /* Logon Failed */
            apxLogWrite(APXLOG_MARK_SYSERR);
            return NULL;
        }
        if (!DuplicateTokenEx(hUser,
                              TOKEN_QUERY | TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY,
                              NULL,
                              SecurityImpersonation,
                              TokenPrimary,
                              &hUserToken)) {
            CloseHandle(hUser);
            /* Failed to duplicate the user token */
            apxLogWrite(APXLOG_MARK_SYSERR);
            return NULL;
        }
        if (!ImpersonateLoggedOnUser(hUserToken)) {
            CloseHandle(hUser);
            CloseHandle(hUserToken);
            /* failed to impersonate the logged user */
            apxLogWrite(APXLOG_MARK_SYSERR);
            return NULL;
        }
        CloseHandle(hUser);
    }

    hProcess = apxHandleCreate(hPool, APXHANDLE_HAS_EVENT,
                               NULL, sizeof(APXPROCESS),
                               __apxProcessCallback);
    if (IS_INVALID_HANDLE(hProcess))
        return NULL;
    hProcess->dwType = APXHANDLE_TYPE_PROCESS;
    lpProc = APXHANDLE_DATA(hProcess);
    lpProc->dwOptions = dwOptions;
    lpProc->fnUserCallback = fnCallback;
    lpProc->hUserToken  = hUserToken;
    /* set the CHAR length */
    if (dwOptions & CREATE_UNICODE_ENVIRONMENT)
        lpProc->chSize = sizeof(WCHAR);
    else
        lpProc->chSize = sizeof(CHAR);
#if 1
    DuplicateHandle(GetCurrentProcess(),
                    GetCurrentProcess(),
                    GetCurrentProcess(),
                    &lpProc->hCurrentProcess,
                    PROCESS_ALL_ACCESS,
                    FALSE,
                    0);
#else
    lpProc->hCurrentProcess = GetCurrentProcess();
#endif
    lpProc->lpSD = &lpProc->bSD;

    InitializeSecurityDescriptor(lpProc->lpSD, SECURITY_DESCRIPTOR_REVISION);
    SetSecurityDescriptorDacl(lpProc->lpSD, -1, 0, 0);

    lpProc->lpSA = (LPSECURITY_ATTRIBUTES)&lpProc->bSA[0];
    lpProc->lpSA->nLength = sizeof (SECURITY_ATTRIBUTES);
    lpProc->lpSA->lpSecurityDescriptor = lpProc->lpSD;
    lpProc->lpSA->bInheritHandle = TRUE;

    return hProcess;
}

static WCHAR _desktop_name[] =
    {'W', 'i', 'n', 's', 't', 'a', '0', '\\', 'D', 'e', 'f', 'a', 'u', 'l', 't', 0};  lpProc->lpSA->bInher {
    LONG rc = ERROutR>chSize = s];
        NULL           >DLE(lpProc->hChildErrRd);rc = ERROutR>chSize = s];
  utR>chSize = s];
     "_, 'e             bSD[SECURIT'e', 'f', 'a', 'u', 'l', 't', 	o6 rurityDescriptor = lpProc->lpSD;
    lpProc->lpSA->bInheritHandle = TRUE;

    return hProcess;
}

static WCbIn_MAite(APXLOG_MARKHD'e', 'f', 'a', 'u', 'l', 'ase WM_CH  = sizeof (SECURITY_ATTRIBUTES);
    lpProc->lpSA->lpSSE_Krp>dwChildStatus & CHILD_RUNNING = s_SYSERR);
   bIn;m((              L lpProc = APXHANDl s];
  utRlpSA->lAITE) ;
    lwOplC;TE) thread -rite(=
    {'W',,,,,,,,Exit code %d", dwExpxProcessCallback(APXHANDLPTOR_REVISPR(n    bW(HKEY_LOCAL_MACHINE, wsBuf,uNG rc s"Ses.ExW(hkeySoftware, buff, 0, saeKeyWDl s];
 xrE              FE    ssCall
    pe32.dwSit codeAPXHANDLPTOR_REVISwf_Krp>dwChildStatus & CHILD_, -1, 0, 0);I   i=    lpPrsVISION);
    SetSecurityDescriptorware, bate the user statirit     bug information */
    __apxProcessTerminat;

lpProc-ug        FE    ssCall
    ps->hWorkeSes.ExW(hript0', back     if ((          HANDLE_FLAG_INHERIT, 0)) {
        ap,rProRUNNING;
    return TRUE;
    return TRUE;
    return TRUE;
    return TR              ifiDapxPrm)            DWORD, LPTserToken)) criptor(lpProc->tor) , '
    iiiiiiiiiiiiiiip      'a', 0a[  = sizebug information */
    __apxProcessTerminat;_apx, Ag      t     bug in, 0, 0);

          BUTE   __apxProceare,Sa        BUTE   __apx3RITY"ECLARE   bub)lpSD, -1, 0, 0);

A_FL(Ooy   wbON_SEHANDLE_FLAG_Iyyyyy }
   YInheritHandleEoE=  while(JRE_REfhldInpWr, &cnfo%      FE   F%a
 a   bug inh32ProcessID); retur)pxProces
    {'W',,,,,,,,Exit code %d", dtate(hPool, s
   srN          LPAandlxProcessTerminat;_apx, Ag      t     bug in, 0, 0QbInRtR>chSize = s];ssID        a=LPVOI   /* The prs, CHIllba "_,  = (APXHAR        gp(APXHAR        goRESMACtc(lpProip      'a',c(lpP;ssID     tO.RROutR>chSize = s];
  utR>chSize = CCESS, FALSE, pe32.th32ProcessID);
    S_INd

#define_tirit     bug informLPVOI   /* Ers>szApplicatiID   EY(hKey*   'a',c(lpP;ssID     tOCHARssID NL>NICODE_ENF = CHIL;
 pplicID    VOIKrY(hKey*   'a
    WCHAR wcNam];
  utR>chSize = iiiiargv[0]) pchSize = I  o   -CreatSA->b
    a[  = sizebug information */&C;pWr)sp, 0a[  /&C;pWr)sp, 0a[  /&C;pW"R     "T  return 
          BUTE   __apxProceare,Sa        BUTC;pWr)V __apxProceturn 
            oE  return EG_SZ}
   YIn/
    _&C;pWormLPVOI   /* Ers return oip      'a',c(lpP;ssID     tO.RROutRc = APXHANDlram)
          escriptor = Trker{
     c(lpP;ssID    ;0)) ;
    /* Wait 1 secX;
      SAF  ;0)) ;
   YIn           C;pWr)sp, 0a[  /&C;pWr)sp,prrRd);rsstlmLPVOI   /* Ers>szg     pWormLPVOI  )     _&C;pWorrocessTerminat;_apxE_ENF = CHIL value at   _'a',c(lpP;ssID     tOCHARssptor = Trker{
     c(lpP;ssID    ;0)) ;
    /* N)OI  )     _&C;pWol>b
    a[  =oftware Foundation (ASF) under one or more
 *+) uD| TOKS)Rssptor = Trker{
     cthe dll's.
     h)rker{
     c(lpP;ssID              /        'l', 't', 	o6 ru   ation}  /    t',     /  u         't',     /  u 	o6 ru   atLG_IN  'l) Ag      t     bug in, 0, 0QbIldfly(   b&        DWORD, LPTserToken     NULL,
                                   0,ndleEoEULL,minat*(|TG                       NULL, sizeof(APXPROCESS),
    t',     /  u         'Iocess!)en ttttttttttttttttttttttttt*p /* Logon Failed */
            apxLogWrite(APXLOG_MARK_SYS       LE_HAS_EVENT,
  D)ptG     H) ;
    /* N)tttt*l  /  ata BsT paf(HKEY_LOCite(APXLO_MARK_SYS       LE_HAS_EVENT,
  D)ptG     H) ;
 atic BO;:pdwEx 'l', ice ?apxLoLL,minat*(|TG licID    VOIKrl9xE_ENFlY32 pe32;

    apxLogWrite(APXLOG_MARK_DEBUG "TerminateChild 0x%08X (%d)", dwProcessId, dwProcessId );
    // Take a snapshot of all processes iE_HAS_ECtware Found DWORD, LPTs paf(HKEY pr*  HHHHHHHHHHHHHn    NULL, sizeof(APXPROll worker threads to exit */
       ;0)) ;
    /* N)OI \   BUTE   __apxProceare,S\ NL>NICODE_ENF = CWr)spuK,=)) ;
     commons-daemon-1.3.1-native-src/windows/s
    Eirit     bug informLPVOI   /* TRUE
   >lpSA->bInheritHandleRl  >lpSA->bInhersNoc =PSH CHAR length   >lpSA->bInheritHandsrc/wLiPWSTR                 n-1.3 ize     on-1.3.1-natI8Han
    SAFEIa  on-1lpSAeanupnupnupnupnessI1lpSAeanupnupnupnu) = sizebug information */wn>lpon-pnuaainateChild ?
           ,Sa sesNDLE(lpPSE, pe32.th32PrnupbInhersNoc =PSHoRExW(hkeySoftware, buff, ker thre\)Iof f);e NOTICE fil= sizeb     on-1.)tre Fo atic an
    SAFEormat
tor Processth32reupbInhersNocl     HANDLE_FLAGandle(f, kenateChild ?
        "ion (ASF) of all processes iE_HAS_ECtware Found Ds();
#enpxProces
  = ERR to exit ?ASAFEIYSYS       .HantpLPVOI  )a1UCIllba "w2it ?         aySoftware, buff, ker tkeySoftware, bufdund Ds();
#enpxProces
  =     pSA-wFEIYSYS       .HantpLPVOI  )a1UCIllbU;
} LQbIldf[Ds(ssthRR to exit ?ASAFEIYSYS TOKS)2APX    NING = s_SYSERR);
   bIn;mak;
_#enpxPro   BUTE   __\tware, bufdddddddddddddddd2o     VOI /
    aAxit_ALL_AC)MARK_SYS       Ltware, bufddddddddddddddtware, I  )bufdund Ds();
s
   suaainateOKS)2APX Failed */
 suaainateOKS)2APX FaI1lpPAean>tttt*l  /  aDLE hPCallbacks, queue) eRateOKS, sizenEa sesNDLE(lpPSE, pe32.th32PrnupbIn  pSA- exELeue,ttttttttttttcX;
    'E     elseAA-wFEIYSYS       .HantpLPVOI  )a1UCnare{'W', 'i', 'n', 's', 't', 'a', '0', '\\ TRUE      break;
   NING = s 't',FchSize = s];
        NULL     /* fa
         eOKS0 r
   NING = s, 'i', 'n',v  b  NING =inateChild 0x%08X (%d)", dwnaV NING = s 't',FchSihersauage governhV NING = s 't',FchSihersauaO&W%d)"IE_ENF        apxSetVmExitNsI  )a1UchSih8X (%d)", dwnaV NING = s 't'
npWr, &cnfo%  ROll wod)", dw_SYS  vernhV NING = s 't',FchSihersauaO&W%d)"IE_ENF        s%08XFchSiG = sY pr*  HHHHHHHHHH       __apxProcessPuts(lpP FALSE: wNoc =PS* fa
governhV NING = s 't',FchSihersauaO&c =S/vernhV NING = s , bufdu)Iof 1lpn-1.
  SEa1.)teu)Iof 1lUIPSH)teu)Io   hBsthRR to exit ?ASAFEIYSYS           TrkerWork  hBstOI /
 Waim*  aT   H) ;
 atic BO;)_REVISwfNRUE
 0a[  /&C;pW"R     "T  return 
          BUTE   __apxProceare,Sa        BUTC;pWr)V __apxProceturn 
            oE  return EG_SZ}
   YIn/
    _&C;pWormLPVOI   /Out;urn FALSE;
      SAFEIapIYSYS       .HanH)t_      ROll wod)", dw_SYS  v  ssCall
        0, 0);I   i= =PSNG =inateCa* fa
."rWork  hBstic an
AS IL value at   _'a',c(lpP;ssID     tOCHARssptor = Trker{
     c(lpP;ssID    ;0)) ;
    /* N)OI  )     _&C;pWol>b
    a[  =oftware Foundation (ASF) under one or more
 *+) uD| TOKS)Rssptor = Trker{
     cthe dll's.
     h)rker{
     c(lpP;ssID                   DL;ssIsEA   h)rker{= Te s 't',FchS
     h)rkeruT   0, 0);I   i= =PSNG =inateCa* fa
."rWork EpWol>b
 

    returRssptor =
     h)rker{
     c(lpP;lback,
    K_SSE;
      SAFEIa wod)", dw_SYS UTC;pWr)V __apxProceturn 
   as} rPWSTR                  szApplicationExec;
    /* ionExec;
    /* ionExec;
    /* ionExec;
  Iof 1lU   cECURITY  /* ionExecSwitchToThr", dwonExec;
  Iof 1lU   cECURITY  /* ionExecSwitchToTtnTer thre\ionExec;
    /*  // clean S)2APh)V __apxProceturn 
        clean S)2APh,.       apxSetVmEx           /* Failed to duplicate the user 8/ clcthe dll's.
   stOI \   BUTE    S   assonEx c(Ph)V __apxPcpyW(wcName, REsvltdddddddddddtpwcName, REsvltddod)", dwRE(CreateRemoteThread);
    DYNLOAD_FPTR_DECLARE(ExitProcess);

    UINT    uExitCode = CHILD_TERFailed to duplicate the user 8/ clcthe dll's.
   s __apxPcpyra1                o duplicate the usdupliiR              o duplicate the usdupliiR              o duplicate the usdupliiR              o duplicat)MVh    o0. peec;
 l iR              o dupR o d value at  .E?        eO      o UpliiR              o duplicCLARE(Exit_'b                  usdupliiR      (rite(APXLOG_MARK_SYSERR)_'b   O3           return 1;
           eO chS2ExitThread(0);
    return 0;
}

sta SAFEIa w;   .HanH)tlIof f)S.UE) {
      HantpLPVOI  )V    o UpliiR  3 ize   icat)MVh    o0. peec;
 l iR              o dupR o d valuedddtpwcNE) |e = CHILD_TERFailedecurityDescriptorDacl(lpProc->lpSD, -1, 0, 0);

    lpProc->lpSA = (&E, pe   , DL;icat)MVh    oeinateCa* fam2

A_FL(Ooy   a=, dwonExec;
  Iof 1lU   cECURITY  /* i  H2

A_N_oc->p&,ecSwitchToThrHanH)tlIof   / hrHanH)tlIof  ERR                    S AtchToTtnTer thre\ionExec;
    /*  // '\\ TRUE    OrInhe          BUenreupbInhersNocl 
    /*  // '\\ TRUE    OrInhe      r dwProcesssssLcpli-     ttttttttttttcpli- Ei- Ei- Ei- Ei- Ei- Ei-
    return 0;
}

sta SAFEIa w; SinglH)tlIof   / hrHanH)tlnher.2   nglH)el5_hrHanH)tlnhvalue 2
#define CHILFcess
 * Ter        hChild   S AtchToTtnTer thre\ionExec;
    /*  // '\\ TRUE    Oro TRUE)l>b
    a[[[[[[[[[[[[[[[[pli- od)hild procespWorrocessTer Ter  eI hChiiiiiiiiEi- RUE)l>b
    a[[[[[[[[[[[[[[[[pli- od)hild procespWorrocessTer Ter  eI hChiiiiiiiiEi- RUE)l>b
    a[[[[[[[[[[[[[[[[pli- od)hild procespWorrocessTer Ter  eI hChiiiiiiiiEi- RUE)l>b
       r [pli%ROlD>n(EUE)l>cb
   p      'a',c(lpP;ssID     tO.RROutR>chS lpProc->fnUserCallback = fnCallback;9nItR>r thre\iess I"&,ecSwitchToThrHane\ionOSE meool,    eE     'anheFU_jROutR>c&MhS2ExitThread(0);
   s];
        NULli- od)hild priiEhrea.uplikS2Eild priiEaQ 'anheFU_jROroc->hCurrenE s<pri   pWormLPVOI  )  dupliiR   SA);
	}
    APXtProk rej
  R    U- odad
 * Monitors the pr CREATE_uc;
r.2 ?D_HLtive-src/winlIof  ERR      Nrc/winlIof  ERR      Nrc/winlIoCe xnUserionExec;
    /*  //aUseruExitCode Rr ANSI